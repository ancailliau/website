#!/usr/bin/ruby -w

# verification des arguments
usage = lambda{|i| warn("Le programme prend 2 arguments: le fichier d'entree (donnees) et le fichier de sortie (resultat)\n\t Exemple : run ../tests/test1 out"); exit(i)}
usage.call(2) if ARGV.length != 2

# ouverture fichier d'entree
begin
  input = File.open(ARGV.shift, 'r')
rescue => e
  warn "Erreur d'ouverture du fichier d'entree"
  usage.call(2)
end

# ouverture fichier de sortie
begin
  output = File.open(ARGV.shift, 'w')
rescue => e
  warn "Erreur d'ouverture du fichier de sortie"
  usage.call(2)
end

# recuperation de N sur la premiere ligne
N = input.gets.to_i

# exemple de lecture de toutes les coordonnees des arbres (A MODIFIER)
input.each do |line|

  x, y = line.scan(/\d+/).collect {|i| i.to_i} # recuperation des coordonnees et conversion en entier
  z = x+y	# et on ne fait rien avec ... a vous de completer

end

# exemple d'ecriture du resultat (cfr exemple enonce) (A MODIFIER)
output.write "0 0\n"
output.write "20000 0\n"
output.write "20000 20000\n"
output.write "0 20000\n"

# fermeture des fichiers
output.close
input.close
