using System.IO;
using System;

public class Program {

	public static void Main(string[] args) {

		// verification des arguments
		if (args.Length != 2) {
			Console.WriteLine("Le programme prend 2 arguments: le fichier d'entree (donnees) et le fichier de sortie (resultat)");
			Console.WriteLine("\t Exemple : run ../tests/test1 output");
			return;
		}

		// ouverture fichier d'entree
		TextReader inputfile;
		try {
			inputfile = new StreamReader(args[0]);
		}	catch(FileNotFoundException) {
			Console.WriteLine("Erreur d'ouverture du fichier d'entree");
			return;
		}

		// ouverture fichier de sortie
		TextWriter outputfile ;
		try {
			outputfile = new StreamWriter(args[1]);
		} catch (FileNotFoundException) {
			Console.WriteLine("Erreur d'ouverture du fichier de sortie");
			return;
		}

		// recuperation de N sur la premiere ligne
		int N = int.Parse( inputfile.ReadLine() );

		// exemple de lecture de toutes les coordonnees des arbres (A MODIFIER)
		string line;
		while((line = inputfile.ReadLine()) != null) {

			// recuperation des coordonnees et conversion en entier
			string[] line_s = line.Split(' ');
			int x = int.Parse(line_s[0]);
			int y = int.Parse(line_s[1]);

			int z = x+y; //et on ne fait rien avec ... a vous de completer

		}

		// exemple d'ecriture du resultat (cfr exemple enonce) (A MODIFIER)
		outputfile.WriteLine("0 0");
		outputfile.WriteLine("20000 0");
		outputfile.WriteLine("20000 20000");
		outputfile.WriteLine("0 20000");

		// fermeture des fichiers
		outputfile.Close();
		inputfile.Close();

	}

}