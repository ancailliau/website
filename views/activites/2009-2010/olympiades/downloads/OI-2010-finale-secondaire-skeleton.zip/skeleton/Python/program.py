#!/usr/bin/env python
import sys, time
import getopt

def main(argv=sys.argv):

	# verification des arguments
	if len(argv) != 3: 		
		print >> sys.stderr, "Le programme prend 2 arguments: le fichier d'entree (donnees) et le fichier de sortie (resultat)"
		print >> sys.stderr, "\t Exemple : run ../tests/test1 output" 
		return 2

	# ouverture fichier d'entree
	try: inputfile = open(argv[1],"r")
	except IOError:
		print >> sys.stderr, "Erreur d'ouverture du fichier d'entree"
		return 2
	
	# ouverture fichier de sortie
	try: outputfile = open(argv[2],"w")
	except IOError:
		print >> sys.stderr, "Erreur d'ouverture du fichier de sortie"
		return 2
		
	# recuperation de N sur la premiere ligne
	N = int(inputfile.readline())
	
	# exemple de lecture de toutes les coordonnees des arbres (A MODIFIER)
	for ligne in inputfile:
		
		[x, y] = map(int,ligne.split())	# recuperation des coordonnees et conversion en entier
		z = x+y	# et on ne fait rien avec ... a vous de completer

	# exemple d'ecriture du resultat (cfr exemple enonce) (A MODIFIER)
	outputfile.write("0 0\n")
	outputfile.write("20000 0\n")
	outputfile.write("20000 20000\n")
	outputfile.write("0 20000\n")

	# fermeture des fichiers 
	inputfile.close()
	outputfile.close()

if __name__ == "__main__":
	sys.exit(main())
