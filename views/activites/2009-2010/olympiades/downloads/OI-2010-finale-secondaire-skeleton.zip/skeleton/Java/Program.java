import java.io.*;

public class Program {
	
	public static void main(String[] args) throws IOException {
		
		// verification des arguments
		if (args.length != 2) {
			System.err.println("Le programme prend 2 arguments: le fichier d'entree (donnees) et le fichier de sortie (resultat)");
			System.err.println("\t Exemple : run ../tests/test1 output");
			System.exit(2);
		}
		
		// ouverture fichier d'entree
		BufferedReader inputfile = null;
		try {
			inputfile = new BufferedReader(new FileReader(args[0]));
		} catch (FileNotFoundException e) {
			System.err.println("Erreur d'ouverture du fichier d'entree");
			System.exit(2);
		}

		// ouverture fichier de sortie
		PrintWriter outputfile = null;
		try {
			outputfile = new PrintWriter(new File(args[1]));
		} catch (FileNotFoundException e) {
			System.err.println("Erreur d'ouverture du fichier de sortie");
			System.exit(2);
		}

		// recuperation de N sur la premiere ligne
		int N = Integer.parseInt(inputfile.readLine());
		
		// exemple de lecture de toutes les coordonnees des arbres (A MODIFIER)
		String line = null;
		while ( (line = inputfile.readLine()) != null)  {
			
			// recuperation des coordonnees et conversion en entier
			String[] line_s = line.split(" "); 
			int x = Integer.parseInt(line_s[0]);
			int y = Integer.parseInt(line_s[1]);
			
			int z = x+y; //et on ne fait rien avec ... a vous de completer
			
		}
		
		// exemple d'ecriture du resultat (cfr exemple enonce) (A MODIFIER)
		outputfile.println("0 0");
		outputfile.println("20000 0");
		outputfile.println("20000 20000");
		outputfile.println("0 20000");
								
		// fermeture des fichiers 
		outputfile.close();
		inputfile.close();

	}
}