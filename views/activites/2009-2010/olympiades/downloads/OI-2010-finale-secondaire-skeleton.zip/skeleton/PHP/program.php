#!/usr/bin/env php
<?php
function main($argv) {

	// verification des arguments
	if (count($argv) != 3) {
		fwrite(STDERR,"Le programme prend 2 arguments: le fichier d'entree (donnees) et le fichier de sortie (resultat)\n");
		fwrite(STDERR,"\t Exemple : run ../tests/test1 output\n");
		exit(2);
	}

	// ouverture fichier d'entree
	$inputfile = fopen($argv[1], 'r');
	if (!$inputfile) {
		fwrite(STDERR,"Erreur d'ouverture du fichier d'entree \n");
		exit(2);
	}

	// ouverture fichier de sortie
	$outputfile = fopen($argv[2], 'w');
	if (! $outputfile) {
		fwrite(STDERR,"Erreur d'ouverture du fichier de sortie \n");
		exit(2);
	}

	// recuperation de N sur la premiere ligne
	$N = intval(fgets($inputfile));

	// exemple de lecture de toutes les coordonnees des arbres (A MODIFIER)
	while (!feof($inputfile)) {

		// recuperation des coordonnees et conversion en entier
		$line = fgets($inputfile);
		$line_s = explode(" ",$line);

		if (count($line_s) == 2) {
			$x = intval($line_s[0]);
			$y = intval($line_s[1]);

			$z = $x + $y ; // et on ne fait rien avec ... a vous de completer
		}
	}

	// exemple d'ecriture du resultat (cfr exemple enonce) (A MODIFIER)
	fwrite($outputfile, "0 0\n");
	fwrite($outputfile, "20000 0\n");
	fwrite($outputfile, "20000 20000\n");
	fwrite($outputfile, "0 20000\n");

	// fermeture des fichiers
	fclose($inputfile);
	fclose($outputfile);

}

main($argv);
?>