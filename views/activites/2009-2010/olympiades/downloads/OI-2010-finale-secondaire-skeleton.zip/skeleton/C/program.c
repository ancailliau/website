#include <unistd.h>
#include <stdio.h>

int 
main (int argc, char **argv)
{
	// verification des arguments
	if (argc != 3 ) {
		fprintf(stderr, "Le programme prend 2 arguments: le fichier d'entree (donnees) et le fichier de sortie (resultat)\n");
		fprintf(stderr, "\t Exemple : run ../tests/test1 out\n");
		return 2;
	}
	
	// ouverture fichier d'entree
	FILE *inputfile;
	if ( (inputfile = fopen(argv[1], "r")) == NULL) {
		fprintf(stderr, "Erreur d'ouverture du fichier d'entree\n");
		return 2;
	}
	
	// ouverture fichier de sortie
	FILE *outputfile;
	if ( (outputfile = fopen(argv[2], "w")) == NULL) {
		fprintf(stderr, "Erreur d'ouverture du fichier de sortie\n");
		return 2;
	}
	
	// recuperation de N sur la premiere ligne
	int N;
	fscanf(inputfile, "%d\n", &N);
	
	// exemple de lecture de toutes les coordonnees des arbres (A MODIFIER)
	int x, y;
	while ( fscanf(inputfile, "%d %d\n", &x, &y) != EOF ) { // recuperation des coordonnees
		
		int z = x+y;	// et on ne fait rien avec ... a vous de completer
	}
	
	// exemple d'ecriture du resultat (cfr exemple enonce) (A MODIFIER)
	fprintf(outputfile, "0 0\n");
	fprintf(outputfile, "20000 0\n");
	fprintf(outputfile, "20000 20000\n");
	fprintf(outputfile, "0 20000\n");
	
	// fermeture des fichiers
	fclose(outputfile);
	fclose(inputfile);
	
	return 0;
}