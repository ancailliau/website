#include <iostream>
#include <sstream>
#include <fstream>
#include <string>

using namespace std;

int main (int argc, char* const *argv)
{
	// verification des arguments
	if (argc != 3 ) {
		cerr << "Le programme prend 2 arguments: le fichier d'entree (donnees) et le fichier de sortie (resultat)\n";
		cerr << "\t Exemple : run ../tests/test1 output\n";
		return 2;
	}
	
	
	// ouverture fichier d'entree
	ifstream inputfile(argv[1],ios::in);
	if ( ! inputfile ) {
		cerr << "Erreur d'ouverture du fichier d'entree";
		return 2;
	}
	
	// ouverture fichier de sortie
	ofstream outputfile(argv[2],ios::out);
	if ( ! outputfile ) {
		cerr << "Erreur d'ouverture du fichier de sortie";
		return 2;
	}
	
	string line;
	int N, x, y;
	
	// recuperation de N sur la premiere ligne
	getline ( inputfile, line );
	istringstream( line ) >> N;
	
	// exemple de lecture de toutes les coordonnees des arbres (A MODIFIER)
	while (! inputfile.eof() ) {  
		
		// recuperation des coordonnees
		getline( inputfile, line );
		istringstream lineparser( line );
		
		lineparser >> x;
		lineparser >> y;
		
		int z = x + y;	// et on ne fait rien avec ... a vous de completer
	}
	
 	// exemple d'ecriture du resultat (cfr exemple enonce) (A MODIFIER)
	outputfile << "0 0\n";
	outputfile << "20000 0\n";
	outputfile << "20000 20000\n";
	outputfile << "0 20000 \n";
	
	// fermeture des fichiers
	inputfile.close();
	outputfile.close();
	
	return 0;
}