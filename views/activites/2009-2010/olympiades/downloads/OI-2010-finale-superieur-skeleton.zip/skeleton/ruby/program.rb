#!/usr/bin/ruby -w

# verification des arguments
usage = lambda{|i| warn("Le programme prend 2 arguments: le fichier d'entree (donnees) et le fichier de sortie (resultat)\n\t Exemple : run ../tests/test1 out"); exit(i)}
usage.call(2) if ARGV.length != 2

# ouverture fichier d'entree
begin
  input = File.open(ARGV.shift, 'r')
rescue => e
  warn "Erreur d'ouverture du fichier d'entree"
  usage.call(2)
end

# ouverture fichier de sortie
begin
  output = File.open(ARGV.shift, 'w')
rescue => e
  warn "Erreur d'ouverture du fichier de sortie"
  usage.call(2)
end

# recuperation de C, L et N sur la premiere ligne, et conversion en entier
C, L, N = input.gets.strip.scan(/\d+/).collect {|i| i.to_i}

# exemple de lecture de toutes les pieces (A MODIFIER)
input.each do |line|

  typedepiece = line.to_i

  # et on ne fait rien avec ... a vous de completer

end

# exemple d'ecriture du resultat (cfr exemple enonce) (A MODIFIER)
output.write "A 2 2\n"
output.write "R\n"
output.write "A 3 2\n"
output.write "A 1 2\n"
output.write "A 1 3\n"
output.write "A 4 1\n"

# fermeture des fichiers
output.close
input.close
