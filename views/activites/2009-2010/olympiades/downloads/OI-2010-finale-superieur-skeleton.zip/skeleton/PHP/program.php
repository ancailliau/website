#!/usr/bin/env php
<?php
function main($argv) {

	// verification des arguments
	if (count($argv) != 3) {
		fwrite(STDERR,"Le programme prend 2 arguments: le fichier d'entree (donnees) et le fichier de sortie (resultat)\n");
		fwrite(STDERR,"\t Exemple : run ../tests/test1 output\n");
		exit(2);
	}

	// ouverture fichier d'entree
	$inputfile = fopen($argv[1], 'r');
	if (!$inputfile) {
		fwrite(STDERR,"Erreur d'ouverture du fichier d'entree \n");
		exit(2);
	}

	// ouverture fichier de sortie
	$outputfile = fopen($argv[2], 'w');
	if (! $outputfile) {
		fwrite(STDERR,"Erreur d'ouverture du fichier de sortie \n");
		exit(2);
	}

	// recuperation de C, L et N sur la premiere ligne, et conversion en entier
	$line_s = explode(" ", fgets($inputfile));
	$C = intval($line_s[0]);
	$L = intval($line_s[1]);
	$N = intval($line_s[2]);

	// exemple de lecture de toutes les pieces (A MODIFIER)
	while (!feof($inputfile)) {

		// recuperation du numero de la piece
		$typedepiece = intval(fgets($inputfile));

		if ($typedepiece != 0) { // afin d'ignorer le saut le ligne potentiel en fin de fichier

			// et on ne fait rien avec ... a vous de completer

		}
	}

	// exemple d'ecriture du resultat (cfr exemple enonce) (A MODIFIER)
	fwrite($outputfile,"A 2 2\n");
	fwrite($outputfile,"R\n");
	fwrite($outputfile,"A 3 2\n");
	fwrite($outputfile,"A 1 2\n");
	fwrite($outputfile,"A 1 3\n");
	fwrite($outputfile,"A 4 1\n");


	// fermeture des fichiers
	fclose($inputfile);
	fclose($outputfile);

}

main($argv);
?>