import java.io.*;

public class Program {
	
	public static void main(String[] args) throws IOException {
		
		// verification des arguments
		if (args.length != 2) {
			System.err.println("Le programme prend 2 arguments: le fichier d'entree (donnees) et le fichier de sortie (resultat)");
			System.err.println("\t Exemple : run ../tests/test1 output");
			System.exit(2);
		}
		
		// ouverture fichier d'entree
		BufferedReader inputfile = null;
		try {
			inputfile = new BufferedReader(new FileReader(args[0]));
		} catch (FileNotFoundException e) {
			System.err.println("Erreur d'ouverture du fichier d'entree");
			System.exit(2);
		}

		// ouverture fichier de sortie
		PrintWriter outputfile = null;
		try {
			outputfile = new PrintWriter(new File(args[1]));
		} catch (FileNotFoundException e) {
			System.err.println("Erreur d'ouverture du fichier de sortie");
			System.exit(2);
		}

		// recuperation de C, L et N sur la premiere ligne, et conversion en entier
		String[] line_s = inputfile.readLine().split(" ");
		int C = Integer.parseInt(line_s[0]);
		int L = Integer.parseInt(line_s[1]);
		int N = Integer.parseInt(line_s[2]);
		
		// exemple de lecture de toutes les pieces (A MODIFIER)
		String line = null;
		while ( (line = inputfile.readLine()) != null)  {
			
			int typedepiece = Integer.parseInt(line);  // recuperation du numero de la piece
			
			// et on ne fait rien avec ... a vous de completer
			
		}
		
		// exemple d'ecriture du resultat (cfr exemple enonce) (A MODIFIER)
		outputfile.println("A 2 2");
		outputfile.println("R");
		outputfile.println("A 3 2");
		outputfile.println("A 1 2");
		outputfile.println("A 1 3");
		outputfile.println("A 4 1");
								
		// fermeture des fichiers 
		outputfile.close();
		inputfile.close();

	}
}