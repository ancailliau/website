#include <iostream>
#include <sstream>
#include <fstream>
#include <string>

using namespace std;

int main (int argc, char* const *argv)
{
	// verification des arguments
	if (argc != 3 ) {
		cerr << "Le programme prend 2 arguments: le fichier d'entree (donnees) et le fichier de sortie (resultat)\n";
		cerr << "\t Exemple : run ../tests/test1 output\n";
		return 2;
	}
	
	
	// ouverture fichier d'entree
	ifstream inputfile(argv[1],ios::in);
	if ( ! inputfile ) {
		cerr << "Erreur d'ouverture du fichier d'entree";
		return 2;
	}
	
	// ouverture fichier de sortie
	ofstream outputfile(argv[2],ios::out);
	if ( ! outputfile ) {
		cerr << "Erreur d'ouverture du fichier de sortie";
		return 2;
	}
	
	string line;
	int C, L, N, typedepiece;
	
	// recuperation de C, L et N sur la premiere ligne, et conversion en entier
	getline ( inputfile, line );
	istringstream lineparser( line ) ;
	lineparser >> C;
	lineparser >> L;
	lineparser >> N;
	
	// exemple de lecture de toutes les pieces (A MODIFIER)
	while (! inputfile.eof() ) {  
		
		// recuperation du numero de la piece
		getline( inputfile, line ); 
		istringstream( line ) >> typedepiece;
		
		// et on ne fait rien avec ... a vous de completer
	}
	
 	// exemple d'ecriture du resultat (cfr exemple enonce) (A MODIFIER)
	outputfile << "A 2 2\n";
	outputfile << "R\n";
	outputfile << "A 3 2\n";
	outputfile << "A 1 2\n";
	outputfile << "A 1 3\n";
	outputfile << "A 4 1\n";
	
	// fermeture des fichiers
	inputfile.close();
	outputfile.close();
	
	return 0;
}