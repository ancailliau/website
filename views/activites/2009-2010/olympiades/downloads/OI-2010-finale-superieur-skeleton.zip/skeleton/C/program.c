#include <unistd.h>
#include <stdio.h>

int
main (int argc, char **argv)
{
	// verification des arguments
	if (argc != 3 ) {
		fprintf(stderr, "Le programme prend 2 arguments: le fichier d'entree (donnees) et le fichier de sortie (resultat)\n");
		fprintf(stderr, "\t Exemple : run ../tests/test1 out\n");
		return 2;
	}

	// ouverture fichier d'entree
	FILE *inputfile;
	if ( (inputfile = fopen(argv[1], "r")) == NULL) {
		fprintf(stderr, "Erreur d'ouverture du fichier d'entree\n");
		return 2;
	}

	// ouverture fichier de sortie
	FILE *outputfile;
	if ( (outputfile = fopen(argv[2], "w")) == NULL) {
		fprintf(stderr, "Erreur d'ouverture du fichier de sortie\n");
		return 2;
	}

	// recuperation de C, L et N sur la premiere ligne, et conversion en entier
	int C, L, N;
	int ret = fscanf(inputfile, "%d %d %d\n", &C, &L, &N);

	// exemple de lecture de toutes les pieces (A MODIFIER)
	int typedepiece;
	while ( fscanf(inputfile, "%d\n", &typedepiece) != EOF ) { // recuperation du numero de la piece

		// et on ne fait rien avec ... a vous de completer
	}

	// exemple d'ecriture du resultat (cfr exemple enonce) (A MODIFIER)
	fprintf(outputfile, "A 2 2\n");
	fprintf(outputfile, "R\n");
	fprintf(outputfile, "A 3 2\n");
	fprintf(outputfile, "A 1 2\n");
	fprintf(outputfile, "A 1 3\n");
	fprintf(outputfile, "A 4 1\n");

	// fermeture des fichiers
	fclose(outputfile);
	fclose(inputfile);

	return 0;
}