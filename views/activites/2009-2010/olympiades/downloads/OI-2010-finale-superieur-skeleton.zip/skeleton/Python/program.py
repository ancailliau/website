#!/usr/bin/env python
import sys, time
import getopt

def main(argv=sys.argv):

	if len(argv) != 3: 		# verification des arguments
		print >> sys.stderr, "Le programme prend 2 arguments: le fichier d'entree (donnees) et le fichier de sortie (resultat)"
		print >> sys.stderr, "\t Exemple : run test1 output" 
		return 2

	try: inputfile = open(argv[1],"r")
	except IOError:
		print >> sys.stderr, "Erreur d'ouverture du fichier d'entree"
		return 2
		
	try: outputfile = open(argv[2],"w")
	except IOError:
		print >> sys.stderr, "Erreur d'ouverture du fichier de sortie"
		return 2
		
	# recuperation de C, L et N sur la premiere ligne, et conversion en entier
	[C, L, N] = map(int,inputfile.readline().split())
	
	# exemple de lecture de toutes les pieces (A MODIFIER)
	for ligne in inputfile:
		
		typedepiece = int(ligne)	# recuperation du numero de la piece

		# et on ne fait rien avec ... a vous de completer

	# exemple d'ecriture de resultat (cfr exemple enonce) (A MODIFIER)
	outputfile.write("A 2 2\n")
	outputfile.write("R\n")
	outputfile.write("A 3 2\n")
	outputfile.write("A 1 2\n")
	outputfile.write("A 1 3\n")
	outputfile.write("A 4 1\n")

	inputfile.close()
	outputfile.close()

if __name__ == "__main__":
	sys.exit(main())
